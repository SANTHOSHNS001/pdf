# PDF Annotator with basic JQuery

Improve upon [RavishaHesh/PDFJsAnnotations](https://github.com/RavishaHesh/PDFJsAnnotations)
![Alt text](./Screenshot.png?raw=true "Screenshot")

## Added Features
- Zoom
- [Redo/Undo](https://stackoverflow.com/a/37276884)
- [JQuery Color Picker](https://www.jqueryscript.net/other/Color-Picker-Plugin-jQuery-MiniColors.html)

## License
MIT